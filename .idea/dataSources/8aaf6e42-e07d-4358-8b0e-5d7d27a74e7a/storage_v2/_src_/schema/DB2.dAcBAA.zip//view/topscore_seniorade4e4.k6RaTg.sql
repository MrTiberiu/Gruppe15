create view topscore_seniorade4e4 as
select `db2`.`utover`.`Navn` AS `Navn`
from `db2`.`utover`
limit 10;

