create definer = root@`%` view topscore_seniorade as
select `db2`.`seniora`.`Score` AS `Score`, `db2`.`seniora`.`Year` AS `Year`
from `db2`.`seniora`
limit 10;

