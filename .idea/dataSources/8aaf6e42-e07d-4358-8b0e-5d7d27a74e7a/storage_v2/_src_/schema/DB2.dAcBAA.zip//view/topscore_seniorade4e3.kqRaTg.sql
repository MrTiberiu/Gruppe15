create view topscore_seniorade4e3 as
select `db2`.`juniorc`.`UtoverFK` AS `UtoverFK`
from `db2`.`juniorc`
limit 10;

