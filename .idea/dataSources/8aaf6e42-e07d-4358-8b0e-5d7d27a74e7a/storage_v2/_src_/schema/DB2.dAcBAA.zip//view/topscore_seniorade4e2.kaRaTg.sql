create view topscore_seniorade4e2 as
select `db2`.`juniorb`.`UtoverFK` AS `UtoverFK`
from `db2`.`juniorb`
limit 10;

