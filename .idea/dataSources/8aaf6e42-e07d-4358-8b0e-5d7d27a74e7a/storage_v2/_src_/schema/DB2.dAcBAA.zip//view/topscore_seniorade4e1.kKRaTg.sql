create view topscore_seniorade4e1 as
select `db2`.`juniora`.`UtoverFK` AS `UtoverFK`
from `db2`.`juniora`
limit 10;

