create view topscore_seniorade4e as
select `db2`.`seniora`.`UtoverFK` AS `UtoverFK`
from `db2`.`seniora`
limit 10;

