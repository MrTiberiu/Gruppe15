create view topscore_juniora as
select `db9`.`utover`.`Navn` AS `Navn`, `db9`.`juniora`.`Score` AS `Score`, `db9`.`juniora`.`Ar` AS `Ar`
from (`db9`.`juniora`
         join `db9`.`utover` on (`db9`.`juniora`.`UtoverID` = `db9`.`utover`.`UtoverID`));

