create
    definer = `mariadb.sys`@localhost procedure AddGeometryColumn(IN catalog varchar(64), IN t_schema varchar(64),
                                                                  IN t_name varchar(64), IN geometry_column varchar(64),
                                                                  IN t_srid int)
begin
  set @qwe= concat('ALTER TABLE ', t_schema, '.', t_name, ' ADD ', geometry_column,' GEOMETRY REF_SYSTEM_ID=', t_srid); PREPARE ls from @qwe; execute ls; deallocate prepare ls; end;

