create definer = root@`%` view topscore_utover1 as
select `db7`.`utover`.`UtoverID` AS `UtoverID`,
       `db7`.`utover`.`Navn`     AS `Navn`,
       `db7`.`utover`.`Klubb`    AS `Klubb`,
       `db7`.`utover`.`Fodt`     AS `Fodt`
from `db7`.`utover`
limit 10;

