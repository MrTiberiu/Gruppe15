create definer = root@`%` view topscore_juniorc1 as
select `db7`.`juniorc`.`ResultatID`  AS `RESULTATID`,
       `db7`.`juniorc`.`UtoverID`    AS `UTOVERID`,
       `db7`.`juniorc`.`3000m`       AS `3000M`,
       `db7`.`juniorc`.`60sec`       AS `60SEC`,
       `db7`.`juniorc`.`Kroppshev`   AS `KROPPSHEV`,
       `db7`.`juniorc`.`Sargeant`    AS `SARGEANT`,
       `db7`.`juniorc`.`Beveglighet` AS `BEVEGLIGHET`,
       `db7`.`juniorc`.`Year`        AS `YEAR`
from `db7`.`juniorc`
limit 10;

