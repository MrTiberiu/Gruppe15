create view topscore_en as
select `db7`.`utover`.`Navn`           AS `Navn`,
       `db7`.`juniora`.`Score`         AS `Score`,
       `db7`.`juniora`.`Watt5000m`     AS `Watt5000m`,
       `db7`.`juniora`.`Tid5000m`      AS `Tid5000m`,
       `db7`.`juniora`.`Watt2000m`     AS `Watt2000m`,
       `db7`.`juniora`.`Tid2000m`      AS `Tid2000m`,
       `db7`.`juniora`.`Watt60sec`     AS `Watt60sec`,
       `db7`.`juniora`.`Prosentliggro` AS `Prosentliggro`,
       `db7`.`juniora`.`Kiloliggro`    AS `Kiloliggro`,
       `db7`.`juniora`.`CmSargeant`    AS `CmSargeant`,
       `db7`.`juniora`.`AntallBeveg`   AS `AntallBeveg`,
       `db7`.`juniora`.`Ar`            AS `Ar`
from (`db7`.`juniora`
         join `db7`.`utover` on (`db7`.`juniora`.`UtoverID` = `db7`.`utover`.`UtoverID`))
where `db7`.`utover`.`UtoverID` = 100;

