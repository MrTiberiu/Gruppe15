create definer = root@`%` view topscore_juniora1 as
select `db7`.`juniora`.`ResultatID`    AS `ResultatID`,
       `db7`.`juniora`.`UtoverID`      AS `UtoverID`,
       `db7`.`juniora`.`Score`         AS `Score`,
       `db7`.`juniora`.`Watt5000m`     AS `Watt5000m`,
       `db7`.`juniora`.`Tid5000m`      AS `Tid5000m`,
       `db7`.`juniora`.`Watt2000m`     AS `Watt2000m`,
       `db7`.`juniora`.`Tid2000m`      AS `Tid2000m`,
       `db7`.`juniora`.`Watt60sec`     AS `Watt60sec`,
       `db7`.`juniora`.`Prosentliggro` AS `Prosentliggro`,
       `db7`.`juniora`.`Kiloliggro`    AS `Kiloliggro`,
       `db7`.`juniora`.`CmSargeant`    AS `CmSargeant`,
       `db7`.`juniora`.`AntallBeveg`   AS `AntallBeveg`,
       `db7`.`juniora`.`Ar`            AS `Ar`
from `db7`.`juniora`
limit 10;

