create definer = root@`%` view topscore_seniora1 as
select `db7`.`seniora`.`ResultatID`     AS `ResultatID`,
       `db7`.`seniora`.`UtoverID`       AS `UtoverID`,
       `db7`.`seniora`.`Score`          AS `Score`,
       `db7`.`seniora`.`Watt5000m`      AS `Watt5000m`,
       `db7`.`seniora`.`Tid5000m`       AS `Tid5000m`,
       `db7`.`seniora`.`Watt2000m`      AS `Watt2000m`,
       `db7`.`seniora`.`Tid2000m`       AS `Tid2000m`,
       `db7`.`seniora`.`Watt60sec`      AS `Watt60sec`,
       `db7`.`seniora`.`ProsentLiggIRo` AS `ProsentLiggIRo`,
       `db7`.`seniora`.`KgLiggIRo`      AS `KgLiggIRo`,
       `db7`.`seniora`.`ProsentKneby`   AS `ProsentKneby`,
       `db7`.`seniora`.`KgKneby`        AS `KgKneby`,
       `db7`.`seniora`.`AntallBeveg`    AS `AntallBeveg`,
       `db7`.`seniora`.`Year`           AS `Year`
from `db7`.`seniora`
limit 10;

