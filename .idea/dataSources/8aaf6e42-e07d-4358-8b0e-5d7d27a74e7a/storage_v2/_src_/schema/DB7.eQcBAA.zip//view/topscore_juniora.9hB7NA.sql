create definer = root@`%` view topscore_juniora as
select `db7`.`utover`.`Navn` AS `Navn`, `db7`.`juniora`.`Score` AS `Score`, `db7`.`juniora`.`Ar` AS `Ar`
from (`db7`.`juniora`
         join `db7`.`utover` on (`db7`.`juniora`.`UtoverID` = `db7`.`utover`.`UtoverID`));

