create definer = root@`%` view topscore_juniorb1 as
select `db7`.`juniorb`.`ResultatID`  AS `ResultatID`,
       `db7`.`juniorb`.`UtoverID`    AS `UtoverID`,
       `db7`.`juniorb`.`Score`       AS `Score`,
       `db7`.`juniorb`.`Sek3000m`    AS `Sek3000m`,
       `db7`.`juniorb`.`Tid3000m`    AS `Tid3000m`,
       `db7`.`juniorb`.`Watt2000m`   AS `Watt2000m`,
       `db7`.`juniorb`.`Tid2000m`    AS `Tid2000m`,
       `db7`.`juniorb`.`Watt60sec`   AS `Watt60sec`,
       `db7`.`juniorb`.`AntalKrHev`  AS `AntalKrHev`,
       `db7`.`juniorb`.`CmSargeant`  AS `CmSargeant`,
       `db7`.`juniorb`.`AntallBeveg` AS `AntallBeveg`,
       `db7`.`juniorb`.`Year`        AS `Year`
from `db7`.`juniorb`
limit 10;

