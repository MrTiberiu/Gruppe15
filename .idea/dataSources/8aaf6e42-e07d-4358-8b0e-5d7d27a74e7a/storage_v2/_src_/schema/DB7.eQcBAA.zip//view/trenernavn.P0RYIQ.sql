create definer = root@`%` view trenernavn as
select `db7`.`trener`.`Navn` AS `Navn`, `db7`.`trener`.`Klubb` AS `Klubb`
from `db7`.`trener`;

